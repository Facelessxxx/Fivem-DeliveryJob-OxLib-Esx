Config = {}

Config.JobLocations = {
    Start = {
        label = "Start Delivery Job",
        coords = vector3(-1311.209106, -3405.810303, 13.940153),
        heading = 180.0,
        npcModel = "cs_floyd"
    },
    Pickup = {
        label = "Pickup Point",
        coords = vector3(-1307.442261, -3389.564209, 13.940153),
        heading = 90.0,
        npcModel = "s_m_m_postal_01"
    },
    Delivery = {
        label = "Delivery Point",
        coords = vector3(-1312.770020, -3398.801514, 13.940153),
        heading = 270.0,
        npcModel = "s_m_m_postal_01"
    }
}

Config.DeliveryOutfit = {
    male = {
        jacket = { component_id = 11, drawable = 81, texture = 0 },  -- Top/Jacket
        pants = { component_id = 4, drawable = 3, texture = 2 },   -- Pants
        shoes = { component_id = 6, drawable = 8, texture = 2 },    -- Shoes
        arms = { component_id = 3, drawable = 57, texture = 0 }     -- Arms
    },
    female = {
        jacket = { component_id = 11, drawable = 79, texture = 0 }, -- Top/Jacket
        pants = { component_id = 4, drawable = 35, texture = 0 },   -- Pants
        shoes = { component_id = 6, drawable = 1, texture = 0 },    -- Shoes
        arms = { component_id = 3, drawable = 14, texture = 0 }     -- Arms
    }
}

Config.DeliveryVehicle = {
    model = "benson",
    spawnCoords = vector4(-1295.0, -3405.0, 13.940153, 180.0) -- x, y, z, heading
}

Config.Reward = 500
Config.Item = "delivery_package"
Config.ProgressBarTime = 5000
Config.Debug = true -- Set to true to enable debugging, false to disable



