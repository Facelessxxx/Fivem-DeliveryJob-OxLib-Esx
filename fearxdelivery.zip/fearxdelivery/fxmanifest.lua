fx_version 'cerulean'
game 'gta5'

author 'faceless'
description 'A Test Delivery Script'
version '1.0.0'


client_scripts {
    'Config.lua',
    'client.lua'
}

server_scripts {
    'Config.lua',
    'server.lua'
}


dependencies {
    'ox_lib',       
    'ox_inventory', 
    'ox_target'     
}


lua54 'yes'
