
RegisterNetEvent('delivery:givePackage', function()
    local xPlayer = source


    exports.ox_inventory:AddItem(xPlayer, Config.Item, 1)


    TriggerClientEvent('ox_lib:notify', xPlayer, { type = 'success', description = 'You received a delivery package!' })
end)


RegisterNetEvent('delivery:completeJob', function()
    local xPlayer = source

    
    local removed = exports.ox_inventory:RemoveItem(xPlayer, Config.Item, 1)

    if removed then

        exports.ox_inventory:addCash(xPlayer, Config.Reward)

        -- Notify the player
        TriggerClientEvent('ox_lib:notify', xPlayer, { type = 'success', description = 'You received $' .. Config.Reward })
    else
        TriggerClientEvent('ox_lib:notify', xPlayer, { type = 'error', description = 'Failed to deliver the package!' })
    end
end)
