lib = exports.ox_lib

local inProgress = false
local npcs = {}
local deliveryVehicle = nil

local function debugPrint(message)
    if Config.Debug then
        print("[DEBUG] " .. message)
    end
end

local function spawnNPCAndInteraction(locationKey)
    local loc = Config.JobLocations[locationKey]
    if not loc then
        debugPrint("Invalid location key: " .. locationKey)
        return
    end

    local model = GetHashKey(loc.npcModel)
    RequestModel(model)
    while not HasModelLoaded(model) do
        Wait(10)
    end

    local npc = CreatePed(4, model, loc.coords.x, loc.coords.y, loc.coords.z - 1.0, loc.heading, false, true)
    SetEntityAsMissionEntity(npc, true, true)
    FreezeEntityPosition(npc, true)
    SetEntityInvincible(npc, true)
    TaskStartScenarioInPlace(npc, 'WORLD_HUMAN_CLIPBOARD', 0, true)
    SetBlockingOfNonTemporaryEvents(npc, true)

    debugPrint("Spawned NPC for " .. locationKey .. " at " .. json.encode(loc.coords))
    npcs[locationKey] = npc

    exports.ox_target:addLocalEntity(npc, {
        {
            name = locationKey .. "_interaction",
            event = "delivery:interact",
            label = locationKey == "Start" and "Start Delivery Job" or (locationKey == "Pickup" and "Pick up the package" or "Deliver the package"),
            icon = "fa-solid fa-box",
            locationKey = locationKey -- Pass the locationKey for logic
        }
    })
end

local function applyDeliveryOutfit()
    local ped = PlayerPedId()
    local gender = IsPedMale(ped) and "male" or "female"
    debugPrint("Player gender detected: " .. gender)

    local outfitData = Config.DeliveryOutfit[gender]

    if outfitData then
        -- Apply outfit components based on the config
        for key, component in pairs(outfitData) do
            SetPedComponentVariation(ped, component.component_id, component.drawable, component.texture, 0)
            debugPrint("Applied " .. key .. " with component_id: " .. component.component_id .. ", drawable: " .. component.drawable .. ", texture: " .. component.texture)
        end
        debugPrint("Delivery outfit applied for " .. gender)
    else
        debugPrint("No delivery outfit found for " .. gender)
        TriggerEvent('ox_lib:notify', { type = 'error', description = 'No delivery outfit found for your gender.' })
    end
end

local function spawnDeliveryVehicle()
    local model = GetHashKey(Config.DeliveryVehicle.model)
    RequestModel(model)
    while not HasModelLoaded(model) do
        Wait(10)
    end

    local coords = Config.DeliveryVehicle.spawnCoords
    deliveryVehicle = CreateVehicle(model, coords.x, coords.y, coords.z, coords.w, true, false)
    SetVehicleNumberPlateText(deliveryVehicle, "DELIVER")
    SetVehicleOnGroundProperly(deliveryVehicle)
    TaskWarpPedIntoVehicle(PlayerPedId(), deliveryVehicle, -1)

    debugPrint("Spawned delivery vehicle: " .. Config.DeliveryVehicle.model)
end

RegisterNetEvent('delivery:interact', function(data)
    local locationKey = data.locationKey
    if locationKey == "Start" then
        debugPrint("Starting delivery job.")

        -- Play an animation
        RequestAnimDict("mp_clothing@female@shirt")
        while not HasAnimDictLoaded("mp_clothing@female@shirt") do
            Wait(10)
        end
        TaskPlayAnim(PlayerPedId(), "mp_clothing@female@shirt", "try_shirt_positive_a", 8.0, 8.0, 3000, 49, 0, false, false, false)
        Wait(3000)

        applyDeliveryOutfit()
        spawnDeliveryVehicle()

        TriggerEvent('ox_lib:notify', { type = 'success', description = 'Delivery job started! Head to the pickup NPC.' })
        inProgress = true
    elseif locationKey == "Pickup" and inProgress then
        debugPrint("Starting pickup process.")

        local parameters = {
            duration = Config.ProgressBarTime,
            position = 'bottom',
            label = 'Picking up package...',
            useWhileDead = false,
            canCancel = true,
            disable = {
                move = true,
                car = true,
                combat = true,
            },
        }

        debugPrint("ProgressCircle parameters: " .. json.encode(parameters))

        local success = exports.ox_lib:progressCircle(parameters)

        if not success then
            TriggerEvent('ox_lib:notify', { type = 'error', description = 'Canceled picking up the package!' })
            debugPrint("Pickup process canceled.")
            return
        end

        TriggerServerEvent('delivery:givePackage')
        TriggerEvent('ox_lib:notify', { type = 'success', description = 'Package picked up! Head to the delivery NPC.' })
        debugPrint("Package picked up.")
    elseif locationKey == "Delivery" and inProgress then
        debugPrint("Starting delivery process.")

        local itemCount = exports.ox_inventory:Search('count', Config.Item)
        debugPrint("Item count for delivery: " .. tostring(itemCount))

        if not itemCount or itemCount < 1 then
            TriggerEvent('ox_lib:notify', { type = 'error', description = 'You don’t have the delivery package!' })
            debugPrint("Player does not have the required item.")
            return
        end

        local parameters = {
            duration = Config.ProgressBarTime,
            position = 'bottom',
            label = 'Delivering package...',
            useWhileDead = false,
            canCancel = true,
            disable = {
                move = true,
                car = true,
                combat = true,
            },
        }

        debugPrint("ProgressCircle parameters: " .. json.encode(parameters))

        local success = exports.ox_lib:progressCircle(parameters)

        if not success then
            TriggerEvent('ox_lib:notify', { type = 'error', description = 'Canceled delivering the package!' })
            debugPrint("Delivery process canceled.")
            return
        end

        TriggerServerEvent('delivery:completeJob')
        TriggerEvent('ox_lib:notify', { type = 'success', description = 'Package delivered! Job complete.' })
        debugPrint("Package delivered. Job complete.")

        inProgress = false
        DeleteEntity(deliveryVehicle)
    end
end)

CreateThread(function()
    for name, loc in pairs(Config.JobLocations) do
        spawnNPCAndInteraction(name)

        local blip = AddBlipForCoord(loc.coords)
        SetBlipSprite(blip, 514)
        SetBlipScale(blip, 0.8)
        SetBlipColour(blip, 2)
        BeginTextCommandSetBlipName('STRING')
        AddTextComponentSubstringPlayerName(loc.label)
        EndTextCommandSetBlipName(blip)
        debugPrint("Added blip for " .. name .. " at " .. json.encode(loc.coords))
    end
end)
